export default function App() {
  return <h1>BudgetBuddy App Running 🚀</h1>;
}